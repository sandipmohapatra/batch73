package com.jspiders.hibernate.dto;
//import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "ufo_table")
public class UFODTO {// implements Serializable {

	public UFODTO() 
	{
		System.out.println(this.getClass().getSimpleName() + " created");
	}

	@Id
	@Column(name = "ufo_id")
	private int ufoId;
	@Column(name = "shape")
	private String shape;
	@Column(name = "speed")
	private double speed;
	@Column(name = "colour")
	private String colour;

	public int getUfoId() {
		return ufoId;
	}

	public void setUfoId(int ufoId) {
		this.ufoId = ufoId;
	}

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	@Override
	public String toString() {
		return "UFODTO [ufoId=" + ufoId + ", shape=" + shape + ", speed="
				+ speed + ", colour=" + colour + "]";
	}
	
}
