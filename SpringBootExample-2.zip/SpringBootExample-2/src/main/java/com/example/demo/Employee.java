package com.example.demo;

import org.springframework.stereotype.Component;

@Component("emp")
public class Employee 
{
int empno;
String name;
float sal;
void input(int empno,String name,float sal)
{
	this.empno=empno;
	this.name=name;
	this.sal=sal;
}
void display()
{
	System.out.println("the empno is "+empno);
	System.out.println("the name is "+name);
	System.out.println("the salary is "+sal);
	}
}
