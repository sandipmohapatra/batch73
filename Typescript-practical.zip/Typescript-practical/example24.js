var newArray = [0, "", true, [], function () { }];
newArray[0] = 10;
newArray[1] = "John";
newArray[2] = true;
newArray[3] = ["A", "B"];
newArray[4] = function () {
    console.log("Function in Array");
};
for (var _i = 0, _a = newArray[3]; _i < _a.length; _i++) {
    var item = _a[_i];
    console.log(item);
}
newArray[4]();
