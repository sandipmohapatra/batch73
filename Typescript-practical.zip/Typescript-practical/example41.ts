let product:any = {
    Name: "Samsung TV",
    Price: 45000.55,
    InStock:true,
    ShippedTo: ["Delhi","Hyd"],
    Total: function(){},
    Mfd: new Date()
}
console.log(`Name is ${typeof product.Name}\n Price is ${typeof product.Price}\n InStock is ${typeof product.InStock}\n ShippedTo is ${typeof product.ShippedTo}\nTotal is ${typeof product.Total}\n Mfd is ${typeof product.Mfd} `);
