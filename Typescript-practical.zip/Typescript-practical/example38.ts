let data:any[] = [
    [{Name:"TV", Price:30045.55}],
    [{Name:"Shirt", Price:5600.55}]
];
console.log(data[1][0].Price);
