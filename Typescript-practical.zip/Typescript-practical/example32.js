var values = [10, 20, 30];
var a = values[0], b = values[1], c = values[2];
console.log("A=" + a + "\nB=" + b + "\nC=" + c);
