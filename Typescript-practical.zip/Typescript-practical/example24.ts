let newArray:any[] = [0,"",true,[],function(){}];
newArray[0] = 10;
newArray[1] = "John";
newArray[2] = true;
newArray[3] = ["A", "B"];
newArray[4] = function(){
    console.log("Function in Array");
};
for(var item of newArray[3]) {
    console.log(item);
}
newArray[4]();
