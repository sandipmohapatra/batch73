var Name = "Samsung TV";
var Price = 45000.55;
var isInStock = true;
console.log("Name=" + Name + "\nPrice=" + Price + "\nStock=" + ((isInStock == true) ? "Available" : "Out of Stock"));
