console.log("Welcome to TypeScript");
console.log("Hello ! World");


step 1:-how to compile a typescript program
---------------------------------------------------
tsc example1.ts
---------------------------------------------------------
* after compilation it will be converted into javascript(js)
-----------------------------------------------------
step 2:-to run the javascript
---------------------------------------
node example1.js
-----------------------------------------------
