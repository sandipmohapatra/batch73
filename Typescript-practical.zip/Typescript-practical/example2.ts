function f1() {
var x = 10; 
if(x==10) 
{
var y; 
y=20;
}
console.log(`x=${x}\n y=${y}`); 
}
f1();