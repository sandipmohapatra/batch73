let values:number[] = [10, 20, 30];
let [a,b,c] = values;
console.log(`A=${a}\nB=${b}\nC=${c}`);
