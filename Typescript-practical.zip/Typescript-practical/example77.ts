enum ErrorCodes 
{
    OK = 200,
    Created = 201,
    Accepted = 202,
    NonAuthorative = 203,
    NoContent
}
console.log(`NoContent Status Code: ${ErrorCodes.NoContent}`);           