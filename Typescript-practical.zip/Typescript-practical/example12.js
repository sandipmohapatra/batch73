var msg = "Welcome to javaScript. You are learning javaScript String Methods.";
console.log(msg);
var newString = msg.replace(/javascript/gi, "TypeScript");
console.log(newString);
