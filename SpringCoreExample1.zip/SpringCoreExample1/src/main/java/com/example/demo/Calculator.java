package com.example.demo;

import org.springframework.stereotype.Component;

@Component("calc")
public class Calculator 
{
public int sum(int a,int b)
{
	return a+b;
}
public int sub(int a,int b)
{
	return a-b;
}
public int mul(int a,int b)
{
	return a*b;
}
public int div(int a,int b)
{
	return a/b;
}
public void welcome()
{
	System.out.println("welcome to spring boot");
}

}
