package com.example.demo;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringCoreExample1Application {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(SpringCoreExample1Application.class, args);
		Calculator cl=ac.getBean("calc",Calculator.class);
		cl.welcome();
		System.out.println("Enter 2 nos");
		Scanner ob=new Scanner(System.in);
		int a=ob.nextInt();
		int b=ob.nextInt();
		System.out.println("The sum is "+cl.sum(a, b));
		System.out.println("The sub is "+cl.sub(a, b));
		System.out.println("The mul is "+cl.mul(a, b));
		System.out.println("The div is "+cl.div(a, b));
		
	}

}
