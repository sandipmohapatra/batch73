package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class CourseUtil
{
public void calculateGst(Course c)
{
	double fee=c.getCfee();
	double discount=fee * 10.0/100;
	double gst=fee*18.0/100;
	c.setDiscount(discount);
	c.setGst(gst);
}
}
