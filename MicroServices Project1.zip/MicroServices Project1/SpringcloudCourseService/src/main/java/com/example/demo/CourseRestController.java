package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/course")
public class CourseRestController 
{
	@Autowired
	private ICourseService service;
	
	//1. to save the data
	@PostMapping
	public ResponseEntity<String> saveCourse(@RequestBody Course c)
	{
		Integer id=service.saveCourse(c);
		ResponseEntity<String> resp=new ResponseEntity("Course"+id+" Created",HttpStatus.CREATED);
		return resp;
	}
//2. to view the data	
@GetMapping("/all")
public List<Course> getAllCourse()
{
	List<Course> allCourse=service.getAllCourse();
	return allCourse;
	}

//3. Fetch course by id.
@GetMapping("/{id}")
public ResponseEntity<?> getCourseId(@PathVariable Integer id)
{
	Course course=service.getOneCourse(id);
	ResponseEntity<?> resp=null;
	try
	{
	 resp=ResponseEntity.ok(course);
	}
	catch(Exception ae)
	{
	 resp=new ResponseEntity<String>("Unable to fetch Data",HttpStatus.INTERNAL_SERVER_ERROR);
	}
		return resp;
	
}

}
